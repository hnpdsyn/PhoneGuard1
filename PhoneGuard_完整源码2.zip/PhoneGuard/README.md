# 🔒 手机防火墙 PhoneGuard

一站式Android手机安全防护应用，整合五大核心防护模块，防止手机被恶意登录和入侵。

## 📋 功能概览

| 模块 | 功能 | 防护场景 |
|------|------|---------|
| 🔒 **应用锁** | 为指定应用加锁，需验证才能打开 | 手机被他人拿到，保护微信/支付宝/银行等敏感APP |
| 🛡️ **ADB防火墙** | 监控ADB调试连接，检测异常连接 | 防止通过USB/WiFi远程ADB入侵手机 |
| 📸 **入侵检测** | 检测异常解锁行为，拍照/定位/报警 | 多次输错密码触发取证 |
| 📱 **SIM卡防护** | 绑定SIM卡，换卡自动告警 | 手机被盗后换卡使用 |
| 🚪 **登录防护** | 防暴力破解，自动锁定异常来源 | 防止暴力破解密码 |

## 📱 支持的Android版本

- **最低:** Android 9.0 (API 28)
- **目标:** Android 14 (API 34)

## 🏗️ 项目结构

```
PhoneGuard/
├── app/
│   ├── src/main/java/com/phonGuard/
│   │   ├── PhoneGuardApp.kt          # Application入口
│   │   ├── MainActivity.kt           # 主界面
│   │   ├── ui/
│   │   │   ├── LockVerifyActivity.kt  # 应用锁验证弹窗
│   │   │   ├── theme/Theme.kt        # 主题定义
│   │   │   └── screens/              # 各页面
│   │   │       ├── HomeScreen.kt     # 首页仪表盘
│   │   │       ├── AppLockScreen.kt  # 应用锁管理
│   │   │       ├── AdbGuardScreen.kt # ADB防火墙
│   │   │       ├── IntrusionScreen.kt# 入侵检测
│   │   │       ├── SimGuardScreen.kt # SIM卡防护
│   │   │       ├── LoginGuardScreen.kt# 登录防护
│   │   │       ├── MoreScreen.kt     # 更多功能
│   │   │       ├── LogScreen.kt      # 安全日志
│   │   │       └── SettingsScreen.kt # 设置
│   │   ├── service/
│   │   │   ├── AppLockService.kt     # 应用锁服务
│   │   │   ├── AdbGuardService.kt    # ADB防火墙服务
│   │   │   ├── IntrusionDetectorService.kt # 入侵检测服务
│   │   │   ├── SimGuardService.kt    # SIM卡防护服务
│   │   │   └── LoginGuardService.kt  # 登录防护服务
│   │   ├── receiver/
│   │   │   ├── BootReceiver.kt       # 开机自启动
│   │   │   ├── SimChangeReceiver.kt  # SIM卡变化检测
│   │   │   └── AdbStateReceiver.kt   # ADB状态监听
│   │   ├── core/
│   │   │   ├── ConfigManager.kt      # 加密配置管理
│   │   │   ├── SecurityLogger.kt     # 安全日志引擎
│   │   │   ├── NotificationHelper.kt # 通知管理
│   │   │   └── PermissionManager.kt  # 权限管理
│   │   └── model/                    # 数据模型
│   └── src/main/res/                 # 资源文件
├── 打包脚本/
│   ├── build_apk.sh                  # Linux/macOS/Termux打包
│   └── build_apk.bat                 # Windows打包
└── README.md
```

## 🚀 构建与安装

### 环境要求

- **JDK 17+**（[下载](https://adoptium.net/)）
- **Android SDK**（API 28-34）
- **Gradle 8.5**（会自动下载）

### 方式一：Android Studio（推荐）

1. 打开 Android Studio → `File → Open`
2. 选择 `PhoneGuard/` 目录
3. 等待 Gradle 同步完成
4. 点击 `Run ▶` 或 `Build → Build Bundle(s) / APK(s) → Build APK(s)`

### 方式二：命令行打包

**Linux / macOS / Termux：**
```bash
cd PhoneGuard
chmod +x 打包脚本/build_apk.sh
./打包脚本/build_apk.sh
```

**Windows：**
```cmd
cd PhoneGuard
打包脚本\build_apk.bat
```

### 方式三：Termux 手机端打包

如果要在手机上直接编译：
```bash
pkg update && pkg upgrade
pkg install openjdk-17 gradle android-sdk

# 设置 ANDROID_HOME
export ANDROID_HOME=/data/data/com.termux/files/usr/lib/android-sdk

cd PhoneGuard
chmod +x gradlew
./gradlew assembleDebug --no-daemon
```

## 🔧 首次使用指南

1. **安装APK**后打开APP
2. **设置主密码**（设置页面 → 主密码）
3. **授予必要权限**：
   - 使用情况访问权限 → 应用锁需要
   - 通知权限 → 接收告警
   - 摄像头权限 → 入侵检测拍照
   - 位置权限 → 入侵检测定位
4. **开启所需防护模块**，逐个配置
5. 点击首页「开启所有防护」按钮

## ⚠️ 注意事项

- **应用锁**需要开启「使用情况访问权限」
- **入侵检测**受Android系统限制，无法精确获取锁屏失败次数，通过分析屏幕亮起/解锁模式推断
- **ADB防火墙**无法直接关闭ADB（需要系统权限），检测到异常会发送告警通知
- **SIM卡防护**需要电话权限，告警短信功能在Android 10+上受限
- 建议开启「忽略电池优化」防止后台服务被系统杀死

## 📄 技术栈

- **语言:** Kotlin
- **UI:** Jetpack Compose + Material 3
- **架构:** MVVM + Service + BroadcastReceiver
- **存储:** EncryptedSharedPreferences（加密存储）
- **最小SDK:** 28 (Android 9) | 目标SDK: 34 (Android 14)

## 📝 许可证

仅供个人安全防护使用。