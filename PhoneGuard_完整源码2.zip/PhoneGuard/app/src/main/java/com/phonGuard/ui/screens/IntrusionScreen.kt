package com.phonGuard.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.phonGuard.PhoneGuardApp
import com.phonGuard.core.PermissionManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntrusionScreen() {
    val context = LocalContext.current
    val app = PhoneGuardApp.instance
    val config = app.configManager
    var enabled by remember { mutableStateOf(config.intrusionEnabled) }
    var threshold by remember { mutableStateOf(config.intrusionThreshold.toString()) }
    var takePhoto by remember { mutableStateOf(config.intrusionTakePhoto) }
    var trackLocation by remember { mutableStateOf(config.intrusionTrackLocation) }
    var playAlarm by remember { mutableStateOf(config.intrusionPlayAlarm) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                "入侵检测",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                "检测异常解锁行为，自动拍照取证并定位",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("入侵检测", fontWeight = FontWeight.Medium)
                        Switch(
                            checked = enabled,
                            onCheckedChange = {
                                enabled = it
                                config.intrusionEnabled = it
                            }
                        )
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = threshold,
                onValueChange = {
                    threshold = it.filter { c -> c.isDigit() }
                    config.intrusionThreshold = threshold.toIntOrNull() ?: 5
                },
                label = { Text("触发阈值（连续失败次数）") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                supportingText = { Text("达到此次数后触发防护措施，建议3-10次") }
            )
        }

        item {
            Text("触发动作", fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(4.dp))
        }

        item {
            Card {
                Column(modifier = Modifier.padding(16.dp)) {
                    // 拍照
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("前置摄像头拍照取证", fontWeight = FontWeight.Medium)
                            Text(
                                "使用前置摄像头拍摄入侵者照片",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        Switch(
                            checked = takePhoto,
                            onCheckedChange = {
                                takePhoto = it
                                config.intrusionTakePhoto = it
                                if (it && !PermissionManager.hasCameraPermission(context)) {
                                    PermissionManager.requestCamera(
                                        context as? androidx.activity.ComponentActivity ?: return@Switch
                                    )
                                }
                            }
                        )
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    // 定位
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("获取位置信息", fontWeight = FontWeight.Medium)
                            Text(
                                "记录入侵时的GPS位置",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        Switch(
                            checked = trackLocation,
                            onCheckedChange = {
                                trackLocation = it
                                config.intrusionTrackLocation = it
                                if (it && !PermissionManager.hasLocationPermission(context)) {
                                    PermissionManager.requestLocation(
                                        context as? androidx.activity.ComponentActivity ?: return@Switch
                                    )
                                }
                            }
                        )
                    }
                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    // 警报
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("播放警报音+震动", fontWeight = FontWeight.Medium)
                            Text(
                                "发出警报声和强烈震动",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        Switch(
                            checked = playAlarm,
                            onCheckedChange = {
                                playAlarm = it
                                config.intrusionPlayAlarm = it
                            }
                        )
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "注意事项",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "1. 拍照需要摄像头权限\n" +
                                "2. 定位需要位置权限\n" +
                                "3. 由于Android系统限制，无法精确获取锁屏密码失败次数\n" +
                                "4. 入侵检测通过分析屏幕亮起/解锁模式来推断异常行为",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}