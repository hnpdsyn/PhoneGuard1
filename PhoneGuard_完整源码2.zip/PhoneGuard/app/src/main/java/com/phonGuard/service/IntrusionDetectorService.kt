package com.phonGuard.service

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.phonGuard.PhoneGuardApp
import com.phonGuard.R
import com.phonGuard.core.NotificationHelper
import com.phonGuard.core.SecurityLogger
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * 入侵检测服务 - 监听锁屏失败，触发拍照/定位/警报
 */
class IntrusionDetectorService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var currentFailCount = 0
    private var isLocked = false
    private var lastScreenOffTime = 0L

    // 锁屏状态广播接收器
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    lastScreenOffTime = System.currentTimeMillis()
                    isLocked = true
                    currentFailCount = 0 // 屏幕关闭后重置计数
                }
                Intent.ACTION_SCREEN_ON -> {
                    // 屏幕亮起，可能有人尝试解锁
                }
                Intent.ACTION_USER_PRESENT -> {
                    // 用户成功解锁，重置计数
                    if (isLocked) {
                        isLocked = false
                        currentFailCount = 0
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundService()
        registerScreenReceiver()
        startFailCountMonitor()
    }

    private fun startForegroundService() {
        val notification = NotificationHelper.showServiceNotification(
            this,
            PhoneGuardApp.CHANNEL_SERVICE,
            "入侵检测已开启",
            "正在监控异常解锁行为"
        )
        startForeground(NOTIFICATION_ID, notification)
    }

    private fun registerScreenReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, filter, Context.RECEIVER_EXPORTED)
    }

    private fun startFailCountMonitor() {
        // 模拟锁屏失败检测：当屏幕亮起但未解锁时，递增失败计数
        scope.launch {
            while (isActive) {
                try {
                    if (isLocked) {
                        // 检测到屏幕亮起但未解锁，可能是一次失败的尝试
                        // 实际上Android安全限制导致无法直接获取锁屏失败次数
                        // 这里通过检测"屏幕亮起长时间未解锁"来推断
                        val screenOnDuration = System.currentTimeMillis() - lastScreenOffTime
                        if (screenOnDuration > 3000 && screenOnDuration < 10000) {
                            // 屏幕亮起3-10秒未解锁，记为一次失败尝试
                            currentFailCount++
                            checkIntrusionThreshold()
                        }
                    }
                    delay(2000)
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
    }

    /**
     * 手动触发入侵检测（供外部调用）
     */
    fun triggerIntrusionAttempt() {
        scope.launch {
            currentFailCount++
            checkIntrusionThreshold()
        }
    }

    private suspend fun checkIntrusionThreshold() {
        val config = (application as PhoneGuardApp).configManager
        if (!config.intrusionEnabled) return

        val threshold = config.intrusionThreshold
        if (currentFailCount >= threshold) {
            handleIntrusionDetected()
            currentFailCount = 0 // 触发后重置
        }
    }

    private suspend fun handleIntrusionDetected() {
        val config = (application as PhoneGuardApp).configManager
        val logger = (application as PhoneGuardApp).securityLogger

        logger.logEvent(
            SecurityLogger.SecurityEvent(
                type = "intrusion",
                subType = "detected",
                message = "检测到入侵行为！连续失败次数: $currentFailCount",
                severity = 2
            )
        )

        // 1. 拍照取证
        if (config.intrusionTakePhoto) {
            captureIntruderPhoto()
        }

        // 2. 获取位置
        if (config.intrusionTrackLocation) {
            getCurrentLocation()
        }

        // 3. 播放警报
        if (config.intrusionPlayAlarm) {
            playAlarmSound()
        }

        // 4. 发送通知
        NotificationHelper.sendAlertNotification(
            this,
            PhoneGuardApp.CHANNEL_INTRUSION,
            "🚨 入侵检测告警！",
            "检测到多次解锁失败，已采取防护措施！",
            INTRUSION_ALERT_ID
        )
    }

    private suspend fun captureIntruderPhoto() {
        withContext(Dispatchers.IO) {
            try {
                val cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
                val cameraId = getFrontCameraId(cameraManager) ?: return@withContext

                // 创建照片存储目录
                val photoDir = File(filesDir, "photos").also { it.mkdirs() }
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                    .format(Date())
                val photoFile = File(photoDir, "intruder_$timestamp.jpg")

                // 注意：实际Android拍照需要完整的Camera2 API调用
                // 这里简化实现，记录拍照意图
                val logger = (application as PhoneGuardApp).securityLogger
                logger.logEvent(
                    SecurityLogger.SecurityEvent(
                        type = "intrusion",
                        subType = "photo_captured",
                        message = "已尝试使用前置摄像头拍照取证",
                        severity = 1,
                        details = org.json.JSONObject().apply {
                            put("camera_id", cameraId)
                            put("target_path", photoFile.absolutePath)
                        }
                    )
                )
            } catch (e: Exception) {
                val logger = (application as PhoneGuardApp).securityLogger
                logger.logEvent(
                    SecurityLogger.SecurityEvent(
                        type = "intrusion",
                        subType = "photo_failed",
                        message = "拍照失败: ${e.message}",
                        severity = 0
                    )
                )
            }
        }
    }

    private fun getFrontCameraId(cameraManager: CameraManager): String? {
        try {
            for (cameraId in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(cameraId)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    return cameraId
                }
            }
        } catch (e: CameraAccessException) {
            return null
        }
        return null
    }

    private suspend fun getCurrentLocation() {
        withContext(Dispatchers.IO) {
            try {
                val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
                val location: Location? = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)

                if (location != null) {
                    val logger = (application as PhoneGuardApp).securityLogger
                    logger.logEvent(
                        SecurityLogger.SecurityEvent(
                            type = "intrusion",
                            subType = "location",
                            message = "已获取入侵者位置信息",
                            severity = 1,
                            details = org.json.JSONObject().apply {
                                put("latitude", location.latitude)
                                put("longitude", location.longitude)
                                put("accuracy", location.accuracy)
                            }
                        )
                    )
                }
            } catch (e: SecurityException) {
                // 没有位置权限
            }
        }
    }

    private fun playAlarmSound() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 500, 200, 500, 200, 500),
                        intArrayOf(0, 255, 0, 255, 0, 255),
                        -1
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(longArrayOf(0, 500, 200, 500, 200, 500), -1)
            }

            // 播放系统警报音
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            if (alarmUri != null) {
                val ringtone = RingtoneManager.getRingtone(this, alarmUri)
                ringtone?.play()
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 1003
        private const val INTRUSION_ALERT_ID = 4001
    }
}