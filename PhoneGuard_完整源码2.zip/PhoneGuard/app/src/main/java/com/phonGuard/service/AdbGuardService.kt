package com.phonGuard.service

import android.app.Service
import android.content.Intent
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.phonGuard.PhoneGuardApp
import com.phonGuard.R
import com.phonGuard.core.NotificationHelper
import com.phonGuard.core.SecurityLogger
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.*

/**
 * ADB防火墙服务 - 检测ADB连接状态，防止远程ADB入侵
 */
class AdbGuardService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var lastAdbEnabled = false
    private var lastWifiIp = ""

    override fun onCreate() {
        super.onCreate()
        startForegroundService()
        startMonitoring()
    }

    private fun startForegroundService() {
        val notification = NotificationHelper.showServiceNotification(
            this,
            PhoneGuardApp.CHANNEL_SERVICE,
            "ADB防火墙已开启",
            "正在监控ADB连接状态"
        )
        startForeground(NOTIFICATION_ID, notification)
    }

    private fun startMonitoring() {
        // 定期检查ADB状态
        scope.launch {
            while (isActive) {
                try {
                    checkAdbState()
                } catch (e: Exception) {
                    // ignore
                }
                delay(5000) // 每5秒检查一次
            }
        }

        // 监听网络变化
        registerNetworkCallback()
    }

    private fun registerNetworkCallback() {
        try {
            val connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val networkRequest = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager.registerNetworkCallback(networkRequest, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    scope.launch { checkAdbState() }
                }
                override fun onLost(network: Network) {
                    scope.launch { checkAdbState() }
                }
            })
        } catch (e: Exception) {
            // ignore
        }
    }

    private suspend fun checkAdbState() {
        val config = (application as PhoneGuardApp).configManager
        if (!config.adbGuardEnabled) return

        val currentAdbEnabled = isAdbEnabled()
        val currentWifiIp = getWifiIpAddress()

        if (currentAdbEnabled != lastAdbEnabled) {
            lastAdbEnabled = currentAdbEnabled
            if (currentAdbEnabled) {
                // ADB被开启
                val logger = (application as PhoneGuardApp).securityLogger
                logger.logEvent(
                    SecurityLogger.SecurityEvent(
                        type = "adb",
                        subType = "enabled",
                        message = "检测到ADB调试已开启！",
                        severity = 1
                    )
                )

                NotificationHelper.sendAlertNotification(
                    this,
                    PhoneGuardApp.CHANNEL_ADB_GUARD,
                    "⚠️ ADB调试已开启",
                    "ADB调试功能已被开启，如果非您本人操作请立即检查！",
                    ADB_ALERT_ID
                )

                // 如果开启了拍照取证，自动拍照
                if (config.adbTakePhoto) {
                    captureIntruderPhoto()
                }

                // 如果开启了自动关闭，尝试关闭ADB
                if (config.adbAutoDisable) {
                    disableAdb()
                }
            }
        }

        // 检查WiFi IP变化（无线ADB连接检测）
        if (currentWifiIp.isNotEmpty() && currentWifiIp != lastWifiIp) {
            lastWifiIp = currentWifiIp
            if (currentAdbEnabled) {
                // ADB在WiFi环境下开启，可能存在无线ADB风险
                val logger = (application as PhoneGuardApp).securityLogger
                logger.logEvent(
                    SecurityLogger.SecurityEvent(
                        type = "adb",
                        subType = "wifi_adb",
                        message = "ADB在WiFi环境下开启，IP: $currentWifiIp",
                        severity = 1
                    )
                )
            }
        }
    }

    private fun isAdbEnabled(): Boolean {
        return try {
            Settings.Secure.getInt(
                contentResolver,
                Settings.Global.ADB_ENABLED
            ) == 1
        } catch (e: Exception) {
            false
        }
    }

    private fun disableAdb() {
        try {
            // ADB状态无法通过普通应用API修改，需要系统权限
            // 这里只能检测和告警，提醒用户手动关闭
            NotificationHelper.sendAlertNotification(
                this,
                PhoneGuardApp.CHANNEL_ADB_GUARD,
                "🔴 无法自动关闭ADB",
                "请前往「开发者选项」手动关闭USB调试，防止远程入侵！",
                ADB_DISABLE_ALERT_ID
            )
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun getWifiIpAddress(): String {
        return try {
            val wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val wifiInfo = wifiManager.connectionInfo
            val ipInt = wifiInfo.ipAddress
            "${ipInt and 0xFF}.${(ipInt shr 8) and 0xFF}.${(ipInt shr 16) and 0xFF}.${(ipInt shr 24) and 0xFF}"
        } catch (e: Exception) {
            ""
        }
    }

    private fun captureIntruderPhoto() {
        scope.launch {
            try {
                val cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
                val cameraId = getFrontCameraId(cameraManager) ?: return@launch

                val photoDir = File(filesDir, "adb_photos").also { it.mkdirs() }
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                    .format(Date())
                val photoFile = File(photoDir, "adb_intruder_$timestamp.jpg")

                val logger = (application as PhoneGuardApp).securityLogger
                logger.logEvent(
                    SecurityLogger.SecurityEvent(
                        type = "adb",
                        subType = "photo_captured",
                        message = "ADB检测到入侵，已尝试拍照取证",
                        severity = 1,
                        details = JSONObject().apply {
                            put("camera_id", cameraId)
                            put("target_path", photoFile.absolutePath)
                        }
                    )
                )
            } catch (e: Exception) {
                val logger = (application as PhoneGuardApp).securityLogger
                logger.logEvent(
                    SecurityLogger.SecurityEvent(
                        type = "adb",
                        subType = "photo_failed",
                        message = "ADB拍照失败: ${e.message}",
                        severity = 0
                    )
                )
            }
        }
    }

    private fun getFrontCameraId(cameraManager: CameraManager): String? {
        try {
            for (cameraId in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(cameraId)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    return cameraId
                }
            }
        } catch (e: CameraAccessException) {
            return null
        }
        return null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 1002
        private const val ADB_ALERT_ID = 3001
        private const val ADB_DISABLE_ALERT_ID = 3002
    }
}