#!/bin/bash
# ==========================================
# 手机防火墙 (PhoneGuard) APK 打包脚本
# 适用于 Linux / macOS / Termux
# ==========================================

set -e

echo "=========================================="
echo "  手机防火墙 PhoneGuard - APK 构建"
echo "=========================================="

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

# 检查是否安装了 JDK 17
if ! command -v java &> /dev/null; then
    echo "❌ 未找到 Java，请安装 JDK 17+"
    echo "   Termux: pkg install openjdk-17"
    echo "   Ubuntu: sudo apt install openjdk-17-jdk"
    echo "   macOS:  brew install openjdk@17"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | head -1 | cut -d'"' -f2 | cut -d'.' -f1)
if [ "$JAVA_VERSION" -lt 17 ]; then
    echo "❌ 需要 JDK 17+，当前版本: $(java -version 2>&1 | head -1)"
    exit 1
fi
echo "✅ JDK 版本: $(java -version 2>&1 | head -1)"

# 检查 ANDROID_HOME
if [ -z "$ANDROID_HOME" ]; then
    # 尝试常见路径
    if [ -d "$HOME/Android/Sdk" ]; then
        export ANDROID_HOME="$HOME/Android/Sdk"
    elif [ -d "$HOME/android" ]; then
        export ANDROID_HOME="$HOME/android"
    else
        echo "⚠️ ANDROID_HOME 未设置"
        echo "   请设置: export ANDROID_HOME=/path/to/android/sdk"
        echo "   或安装 Android SDK:"
        echo "     Termux: pkg install android-sdk"
        echo "     Ubuntu: sudo apt install android-sdk"
        exit 1
    fi
fi
echo "✅ ANDROID_HOME: $ANDROID_HOME"
export ANDROID_SDK_ROOT="$ANDROID_HOME"

# 检查 Gradle
if [ ! -f "gradlew" ]; then
    echo "📥 生成 Gradle Wrapper..."
    gradle wrapper --gradle-version 8.5
fi

chmod +x gradlew

echo ""
echo "🔨 开始构建 APK..."
echo "   构建类型: debug"
echo ""

# 执行构建
./gradlew assembleDebug --no-daemon

echo ""
echo "=========================================="
echo "  ✅ 构建完成！"
echo "=========================================="

# 查找生成的 APK
APK_PATH=$(find "$PROJECT_DIR/app/build/outputs/apk" -name "*.apk" 2>/dev/null | head -1)
if [ -n "$APK_PATH" ]; then
    APK_SIZE=$(ls -lh "$APK_PATH" | awk '{print $5}')
    echo "  APK 位置: $APK_PATH"
    echo "  APK 大小: $APK_SIZE"
    echo ""
    echo "  📱 安装到手机:"
    echo "    adb install $APK_PATH"
else
    echo "  ⚠️ 未找到 APK 文件，请检查构建日志"
fi
echo "=========================================="